template<typename T> 
class Sample
{
};

int main()
{
	Sample<int> t1;
	Sample<int, double> t2;
	Sample<int, double, short> t3;
}