#include <iostream>

// C 언어의 가변인자 함수
int sum( ? )
{
	return 0;
}

int main()
{
	int ret = sum( 1,2,3,4,5);
	
	std::cout << ret << std::endl;
}