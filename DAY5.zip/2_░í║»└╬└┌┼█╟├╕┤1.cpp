﻿// 7_가변인자템플릿1 - 225 page

// 가변인자 함수 템플릿
template<typename T> void foo(T a) {}

int main()
{
	foo(1);
	foo(1, 3.4);
	foo(1, 3.4, "A");
}
