#include <iostream>
#include <stdarg.h>

int sum( int cnt, ... )
{
	return 0;
}

int main()
{
	int ret = sum( 5, 1,2,3,4,5);
	
	std::cout << ret << std::endl;
}