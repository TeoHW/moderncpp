// tuple 복사
