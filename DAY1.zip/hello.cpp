#include <iostream>

int main()
{
	std::cout << "hello\n";
}
