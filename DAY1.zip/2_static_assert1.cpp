﻿// 7page
// 64bit 전용프로그램을 작성했다.

int main()
{
	int n = 0;
	int* p = &n;
}
