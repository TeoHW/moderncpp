﻿// 9_enum - 32 page

enum DAYOFWEEK { mon = 0, tue = 2, wed = 3};

int main()
{
	int n1 = mon;
	int mon = 20;
	
	int n2 = mon;
}





