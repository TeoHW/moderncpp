#include <iostream>

// nullptr 원리(구현)

void foo(int* p)    { std::cout << "int*\n";}
void goo(double* p) { std::cout << "double*\n";}


int main()
{
	foo(mynullptr);
	goo(mynullptr);
}