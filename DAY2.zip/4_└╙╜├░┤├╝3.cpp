﻿#include <iostream>

// 임시객체와 함수 인자 - 81 page

class Point
{
public:
	int x, y;

	Point(int a, int b) { std::cout << "Point()" << std::endl; }
	~Point() { std::cout << "~Point()" << std::endl; }
};

void draw_line(const Point& from, const Point& to) {}
void init(Point& pt) { pt.x = 0; pt.y = 0; }

int main()
{
	// (1,2) ~ (7,8) 에 선을 그리고 싶다.

	// 방법 1. 인자로 named object 사용
	Point p1{1, 2};
	Point p2{7, 8};
	draw_line(p1, p2); 

}





