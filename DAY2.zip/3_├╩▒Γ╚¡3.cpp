﻿int main()
{
	int  n1 = 3.4; 
	char c1 = 500; 

	// prevent narrow - 56 page 중간부분
	int n2{ 3.4 };  
	char c2{ 500 }; 

}
