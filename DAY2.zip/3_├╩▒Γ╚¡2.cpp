﻿#include <complex>

int main()
{
	int a1 = 10;
	int b1(10); 
	int x1[2] = { 1,2 };
	std::complex<double> c1(1, 2);
}












