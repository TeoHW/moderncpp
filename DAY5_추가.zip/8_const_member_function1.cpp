#include <iostream>

class Sample
{
public:
	void foo()       { std::cout << "foo\n";}
	void foo() const { std::cout << "foo const\n";}
};

int main()
{
	Sample s;
	const Sample cs;

	s.foo();
	cs.foo();
	
}