class Point 
{
	int x;
	int y;
public:
	void set1(int a, int b) 	// set1(Point* this, int a, int b)
	{							// {
		x = a;					// 		this->x = a;
		y = b;					//		this->y = b;
	}							// }

	void set2(int a, int b) 	
	{							
		x = a;					
		y = b;					
	}							
};

int main()
{
	Point p;
	p.set1(10, 20);	// set1(&p, 10, 20)
	p.set2(10, 20);
}