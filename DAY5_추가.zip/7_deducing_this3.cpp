#include <iostream>

int factorial(int n) {	return n == 1 ? 1 : n* factorial(n-1); }

int main()
{
	std::cout << factorial(5) << std::endl; // 5! => 120

//	auto fact = [](this auto& self, int n) {	return n == 1 ? 1 : n * self(n-1); };

	auto fact = [](int n) {	return n == 1 ? 1 : n * (*this)(n-1); };

}