#include <iostream>

class Point
{
public:
	void set() {}
	void print() const {} 
};

int main()
{
	const Point pt;

	// 상수 객체는 상수 함수만 호출 가능합니다.
	pt.set();
	pt.print();	
}