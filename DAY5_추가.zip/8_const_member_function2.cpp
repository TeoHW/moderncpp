#include <iostream>
#include <memory>

template<typename T>
class vector 
{
	T* buff;
	std::size_t size;
public:
	vector(std::size_t sz, T value ) : size(sz)
	{
		buff = new T[sz];
		std::uninitialized_fill_n(buff, sz, value);
	}
	~vector() { delete[] buff;}
};

int main()
{
	vector<int> v1(10, 3);

	std::cout << v1[0] << std::endl;

//	v[0] = 10;
}