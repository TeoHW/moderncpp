#include <functional>
#include <vector>
#include <iostream>

int main()
{
	std::function<void()> f;

	int n = 0;

	f = [](){ std::cout << "lambda\n";};


	f();
}
