class Sample
{
public:
	// 동일이름의 상수 멤버 함수와 비상수 멤버 함수를 제공하려면

	// 1. C++23 이전까지의 멤버 함수(implicit object parameter) 기술로
	void foo()       { std::cout << "foo\n";}
	void foo() const { std::cout << "foo const\n";}

	// 2. C++23 이후의 explicit object parameter 사용

};

int main()
{
	Sample s;
	const Sample cs;

	s.foo();
	cs.foo();
}