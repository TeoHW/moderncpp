#include <functional>
#include <vector>
#include <iostream>

void foo() { std::cout << "foo\n"; }

class Button
{
public:
	void(*handler)();

	void click() {}
};

int main()
{
	Button btn;

	btn.click();
}
