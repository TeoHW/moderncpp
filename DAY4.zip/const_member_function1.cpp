#include <iostream>

class Point
{
public:
	int xpos, ypos;

	Point(int x, int y) : xpos{x}, ypos{y} {}

	void set(int x, int y);
	void print();
};

void Point::set(int x, int y) 
{
	xpos = x;
	ypos = y;
}

void Point::print() 
{
	std::cout << xpos << ", " << ypos << std::endl;
}


int main()
{
	Point pt{1, 2};

	pt.xpos = 10;   
	pt.set(10, 20); 
	pt.print();     
}