#include <iostream>

class Point
{
	int x, y;
public:
	void set(int a, int b)
	{
		x = a;
		y = b;
	}	
};

int main()
{
	Point p1;
	Point p2;

	p1.set(1, 2);
	p2.set(3, 4);

}