int main()
{
	int n = 0;
	

	double d = 0;


	int x[3] = {1,2,3};
}