void foo(? p) {}
void goo(? p) {}

int main()
{
	int x[3][2] = {0};
	int y[3][2][2] = {0};

	foo(x);
	goo(y);

}