﻿// 4_type_traits3 - 210 page
#include <iostream>


#include <type_traits>

int main()
{
	// 1. 조사하려면
	bool b1 = std::is_pointer<int*>::value;

	// 2. 변형 타입을 얻으려면
	std::remove_pointer<int*>::type n1;
}
