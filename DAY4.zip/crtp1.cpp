#include <iostream>

class Base
{
public:
	void fn()
	{
		// 여기서 파생 클래스 이름(Derived)을 사용할수 없을까 ?
		Derived obj; // ?
	}
};

class Derived : public Base
{

};

int main()
{
	Derived  d;
	d.fn();
}