#include <stdio.h>

void foo(int a, int b)
{
	printf("foo : %d, %d\n", a, b);
}

int main()
{
	? f = &foo;
}