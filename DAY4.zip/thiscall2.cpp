class Dialog 
{
public:
	void member_function(int a) {}
	static void static_member_function(int a) {}
};

void foo(int a) {}

int main()
{
	// 다음중 에러는 ?
	void(*f1)(int) = &foo;
	void(*f2)(int) = &Dialog::member_function;
	void(*f3)(int) = &Dialog::static_member_function;
}