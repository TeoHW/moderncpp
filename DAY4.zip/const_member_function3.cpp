#include <iostream>

template<typename T>
struct less
{
	inline bool operator()(T a, T b)
	{
		return a < b;
	}
};

template<typename T>
void sort(T f)
{
	bool b = f(1, 2);
}

int main()
{
	less<int> cmp;

	sort(cmp);
}
