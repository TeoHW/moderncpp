﻿// 6_람다_지역변수캡쳐1 - 146
#include <iostream>

int g = 10;

int main()
{
	int v1 = 0, v2 = 0;

	auto f2 = [v1, v2](int a) { v1 = a; v2 = a; }; 

	f2(100);

}





