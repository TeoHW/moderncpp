int main()
{
	int n1 = 0;
	int* p1 = &n1;

	n1 = 10;
	p1 = 10;

	int x[3] = {1, 2, 3};


	
}