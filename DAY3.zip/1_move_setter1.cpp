#include <iostream>
#include <fstream>
#include <string>
#include <vector>

// 파일의 모든 내용을 한줄씩 읽어서
// vector 에 저장하는 코드 입니다.
// 개선점을 찾아 보세요

int main()
{
	std::vector<std::string> v;

	std::ifstream fin("1_move_setter1.cpp");

	std::string s;

	while( std::getline(fin, s) )
	{
		v.push_back(s);
	}

	for(const auto& e : v)
		std::cout << e << '\n';
}