﻿// 7_완벽한전달1 - 113 page
#include <iostream>

void foo(int a)  {}
void goo(int& a) { a = 100; }

int main()
{
	int n = 10;

	foo(10);
	goo(n);

	std::cout << n << std::endl;
}

template<typename F, typename T>
void chronometry( F f, T arg)
{
	// 현재 시간 기록
	f(arg);
	// 시간을 구해서 "f(arg)" 수행 시간 출력
}